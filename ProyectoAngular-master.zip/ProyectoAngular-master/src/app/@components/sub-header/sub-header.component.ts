import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-header',
  templateUrl: './sub-header.component.html',
  styleUrls: ['./sub-header.component.css','../../../assets/css/admin.css']
})
export class SubHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
