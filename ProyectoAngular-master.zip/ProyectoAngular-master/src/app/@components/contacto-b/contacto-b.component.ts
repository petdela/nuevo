import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contacto-b',
  templateUrl: './contacto-b.component.html',
  styleUrls: ['./contacto-b.component.css','../../../assets/css/admin.css']
})
export class ContactoBComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    this.ocultar();
  }
  ocultar = () => {
    let header = document.getElementsByTagName("app-header")[0] as HTMLElement;
    let footer = document.getElementsByTagName("app-footer")[0] as HTMLElement;
    header.style.display = "none";
    footer.style.display = "none";
  }
}
