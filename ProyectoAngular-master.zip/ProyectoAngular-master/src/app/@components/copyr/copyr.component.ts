import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-copyr',
  templateUrl: './copyr.component.html',
  styleUrls: ['./copyr.component.css']
})
export class CopyrComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
