import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-featured-ser',
  templateUrl: './featured-ser.component.html',
  styleUrls: ['./featured-ser.component.css']
})
export class FeaturedSerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
