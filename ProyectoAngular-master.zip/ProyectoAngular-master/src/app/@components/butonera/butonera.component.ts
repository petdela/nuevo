import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-butonera',
  templateUrl: './butonera.component.html',
  styleUrls: ['./butonera.component.css']
})
export class ButoneraComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
