import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ButoneraComponent } from './butonera.component';



@NgModule({
  declarations: [ButoneraComponent],
  imports: [
    CommonModule
  ]
})
export class ButoneraModule { }
