import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModificarComponent } from './modificar.component';



@NgModule({
  declarations: [ModificarComponent],
  imports: [
    CommonModule
  ]
})
export class ModificarModule { }
